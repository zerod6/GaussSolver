﻿using System;
using System.IO;
using System.Windows.Forms;

namespace kursovaya
{
    public class FileInput
    {
        private readonly DataGridView dgvMatrix;  // DataGridView для отображения данных

        public FileInput(DataGridView dgv)
        {
            // Проверка, что DataGridView не null
            dgvMatrix = dgv ?? throw new ArgumentNullException(nameof(dgv), "DataGridView не может быть null.");
        }

        // Метод для загрузки данных из файла
        public void LoadFile()
        {
            OpenFileDialog openFileDialog = CreateOpenFileDialog(); // Создаем диалог для выбора файла

            try
            {
                // Если пользователь выбрал файл, читаем его
                if (openFileDialog.ShowDialog() == DialogResult.OK)
                {
                    string[] lines = File.ReadAllLines(openFileDialog.FileName); // Чтение всех строк из файла
                    ParseFileDataToGrid(lines); // Парсим данные в таблицу
                }
            }
            catch (Exception ex)
            {
                // Обрабатываем ошибки при открытии файла
                HandleFileLoadException(ex);
            }
        }

        // Метод для создания диалога выбора файла
        private OpenFileDialog CreateOpenFileDialog()
        {
            return new OpenFileDialog
            {
                Filter = "Текстовые файлы (*.txt)|*.txt|Все файлы (*.*)|*.*", // Устанавливаем фильтр для выбора файлов
                Title = "Выберите файл с данными" // Заголовок окна
            };
        }

        // Метод для обработки ошибок при загрузке файла
        private void HandleFileLoadException(Exception ex)
        {
            MessageBox.Show($"Ошибка при открытии файла: {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }

        // Метод для парсинга данных из файла и заполнения DataGridView
        private void ParseFileDataToGrid(string[] lines)
        {
            if (lines.Length == 0)
            {
                // Если файл пустой, выводим предупреждение
                Logger.LogMessage("Файл пуст. Данные не загружены.", Logger.LogLevel.WARNING);
                return;
            }

            Logger.LogMessage("Начало парсинга данных в таблицу.", Logger.LogLevel.INFO);

            try
            {
                InitializeDataGridView(); // Инициализируем таблицу (очищаем строки и столбцы)

                // Разделяем первую строку файла для получения заголовков столбцов
                string[] headers = lines[0].Split(new[] { ' ', ',' }, StringSplitOptions.RemoveEmptyEntries);
                AddColumnsToDataGrid(headers); // Добавляем столбцы в таблицу

                // Добавляем строки данных
                AddRowsToDataGrid(lines);

                Logger.LogMessage("Парсинг данных завершен.", Logger.LogLevel.INFO);
            }
            catch (Exception ex)
            {
                // Логируем и выводим сообщение об ошибке, если что-то пошло не так
                Logger.LogException(ex);
                MessageBox.Show($"Ошибка парсинга данных: {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Метод для инициализации DataGridView: очищаем строки и столбцы
        private void InitializeDataGridView()
        {
            dgvMatrix.Rows.Clear(); // Очистка строк
            dgvMatrix.Columns.Clear(); // Очистка столбцов
        }

        // Метод для добавления столбцов в DataGridView
        private void AddColumnsToDataGrid(string[] headers)
        {
            for (int i = 0; i < headers.Length; i++)
            {
                // Название столбца зависит от индекса: для последнего столбца ставим "Свободный член"
                string columnHeader = (i < headers.Length - 1) ? $"x{i + 1}" : "Свободный член";
                dgvMatrix.Columns.Add($"col{i}", columnHeader); // Добавляем столбец в DataGridView
            }
        }

        // Метод для добавления строк в DataGridView
        private void AddRowsToDataGrid(string[] lines)
        {
            // Начинаем с 1, так как 0 строка уже использована для заголовков
            for (int i = 1; i < lines.Length; i++)
            {
                string[] rowValues = lines[i].Split(new[] { ' ', ',' }, StringSplitOptions.RemoveEmptyEntries);

                // Проверка, что количество значений в строке совпадает с количеством столбцов
                if (rowValues.Length == dgvMatrix.ColumnCount)
                {
                    dgvMatrix.Rows.Add(rowValues); // Добавляем строку данных в таблицу
                }
                else
                {
                    // Если количество значений в строке неверное, выводим предупреждение
                    Logger.LogMessage($"Ошибка данных: строка {i + 1} содержит неверное количество значений.", Logger.LogLevel.WARNING);
                    MessageBox.Show($"Ошибка: строка {i + 1} содержит неверное количество значений.", "Ошибка данных", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
        }
    }
}
