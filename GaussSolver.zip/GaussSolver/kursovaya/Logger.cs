﻿using System;
using System.IO;

public static class Logger
{
    private static readonly string LogDirectory = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "logs");
    private static readonly string LogFilePath = Path.Combine(LogDirectory, "my_log.log");

    public enum LogLevel
    {
        DEBUG,
        INFO,
        WARNING,
        ERROR,
        CRITICAL
    }

    // Инициализация логгера, создание директории для логов
    public static void SetupLogger()
    {
        if (!Directory.Exists(LogDirectory))
        {
            try
            {
                Directory.CreateDirectory(LogDirectory);
            }
            catch (Exception ex)
            {
                LogError($"Ошибка при создании директории для логов: {ex.Message}");
                throw;
            }
        }

        LogMessage("Logger initialized.", LogLevel.INFO);
    }

    // Логирование сообщений с уровнем
    public static void LogMessage(string message, LogLevel level = LogLevel.INFO)
    {
        string logMessage = FormatLogMessage(message, level);
        Console.WriteLine(logMessage);
        AppendLogToFile(logMessage);
    }

    // Логирование исключений
    public static void LogException(Exception ex)
    {
        string logMessage = $"{DateTime.Now:yyyy-MM-dd HH:mm:ss} - ERROR - Exception occurred: {ex.Message}{Environment.NewLine}";
        logMessage += $"Stack Trace: {ex.StackTrace ?? "No stack trace available"}{Environment.NewLine}";

        if (ex is System.Reflection.TargetInvocationException targetEx)
        {
            logMessage += $"Target Method: {targetEx.TargetSite.Name}{Environment.NewLine}";
        }

        Console.WriteLine(logMessage);
        AppendLogToFile(logMessage);
    }

    // Форматирование лога
    private static string FormatLogMessage(string message, LogLevel level)
    {
        return $"{DateTime.Now:yyyy-MM-dd HH:mm:ss} - {level} - {message}";
    }

    // Запись лога в файл
    private static void AppendLogToFile(string logMessage)
    {
        try
        {
            File.AppendAllText(LogFilePath, logMessage + Environment.NewLine);
        }
        catch (Exception ex)
        {
            LogError($"Ошибка при записи в лог: {ex.Message}");
        }
    }

    // Логирование ошибок
    private static void LogError(string errorMessage)
    {
        Console.WriteLine(errorMessage);
    }
}
