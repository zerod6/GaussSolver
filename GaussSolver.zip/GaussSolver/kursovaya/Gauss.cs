﻿using System;

namespace kursovaya
{
    public static class Gauss
    {
        // Метод для решения системы линейных уравнений методом Гаусса с исключением.
        public static double[] SolveGaussElimination(double[,] matrix)
        {
            int n = matrix.GetLength(0);  // Количество уравнений (строк)
            int m = matrix.GetLength(1) - 1;  // Количество переменных (столбцов минус 1 для свободных членов)
            double[] result = new double[m];  // Массив для хранения решения

            Logger.LogMessage("Запуск метода Гаусса для решения системы уравнений.", Logger.LogLevel.INFO);

            // Прямой ход Гаусса: приведение матрицы к верхнему треугольному виду
            for (int i = 0; i < n; i++)
            {
                // Поиск максимального элемента в текущем столбце для минимизации погрешностей
                int maxRow = i;
                double max = Math.Abs(matrix[i, i]);

                for (int k = i + 1; k < n; k++)
                {
                    if (Math.Abs(matrix[k, i]) > max)
                    {
                        max = Math.Abs(matrix[k, i]);
                        maxRow = k;
                    }
                }

                Logger.LogMessage($"Выбор главного элемента в столбце {i}, строка {maxRow}.", Logger.LogLevel.DEBUG);

                // Если главный элемент близок к нулю, система несовместна
                if (Math.Abs(matrix[maxRow, i]) < 1e-10)
                {
                    Logger.LogMessage("Система несовместна: элемент на главной диагонали равен нулю.", Logger.LogLevel.ERROR);
                    return new double[] { double.NaN };  // Возвращаем NaN для несовместной системы
                }

                // Перестановка строк для обеспечения ненулевого главного элемента
                if (maxRow != i)
                {
                    Logger.LogMessage($"Перестановка строк {i} и {maxRow}.", Logger.LogLevel.DEBUG);
                    SwapRows(matrix, i, maxRow, m + 1);
                }

                // Приведение матрицы к верхнему треугольному виду
                for (int k = i + 1; k < n; k++)
                {
                    if (matrix[k, i] != 0)
                    {
                        double factor = matrix[k, i] / matrix[i, i];
                        for (int j = i; j < m + 1; j++)
                        {
                            matrix[k, j] -= matrix[i, j] * factor;  // Обнуляем элементы под главным
                        }
                    }
                }
            }

            // Проверка на несовместность системы после приведения к верхнему треугольному виду
            for (int i = 0; i < n; i++)
            {
                bool isZeroRow = true;
                for (int j = 0; j < m; j++)
                {
                    if (matrix[i, j] != 0)
                    {
                        isZeroRow = false;
                        break;
                    }
                }

                // Если строка состоит из нулей, но свободный член не равен нулю, система несовместна
                if (isZeroRow && matrix[i, m] != 0)
                {
                    Logger.LogMessage("Система несовместна: строка состоит из нулей, но свободный член не равен нулю.", Logger.LogLevel.ERROR);
                    return new double[] { double.NaN };
                }
            }

            Logger.LogMessage("Система приведена к верхнему треугольному виду. Переход к обратному ходу.", Logger.LogLevel.INFO);

            // Обратный ход: решение системы с верхним треугольным видом
            for (int i = n - 1; i >= 0; i--)
            {
                if (Math.Abs(matrix[i, i]) < 1e-10)
                {
                    Logger.LogMessage("Система имеет бесконечно много решений: элемент на главной диагонали равен нулю.", Logger.LogLevel.ERROR);
                    return new double[] { double.PositiveInfinity };  // Возвращаем бесконечность для бесконечно многих решений
                }

                // Вычисление значения переменной
                result[i] = matrix[i, m] / matrix[i, i];
                Logger.LogMessage($"Решение для переменной {i}: {result[i]}.", Logger.LogLevel.DEBUG);

                // Обновляем остальные элементы свободных членов
                for (int k = i - 1; k >= 0; k--)
                {
                    matrix[k, m] -= matrix[k, i] * result[i];
                }
            }

            Logger.LogMessage("Решение системы получено.", Logger.LogLevel.INFO);
            return result;
        }

        // Метод наименьших квадратов для решения переопределенной системы
        public static double[] SolveLeastSquares(double[,] matrix)
        {
            int n = matrix.GetLength(0);  // Количество уравнений
            int m = matrix.GetLength(1) - 1;  // Количество переменных

            Logger.LogMessage("Запуск метода наименьших квадратов.", Logger.LogLevel.INFO);

            // Создание матрицы A (матрица коэффициентов) и вектора b (свободных членов)
            double[,] A = new double[n, m];
            double[] b = new double[n];

            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < m; j++)
                {
                    A[i, j] = matrix[i, j];
                }
                b[i] = matrix[i, m];
            }

            // Транспонирование матрицы A
            double[,] A_T = TransposeMatrix(A, n, m);
            // Вычисление матрицы ATA = A_T * A
            double[,] ATA = MultiplyMatrices(A_T, A, m, n, m);
            // Вычисление вектора ATb = A_T * b
            double[] ATb = MultiplyMatrixVector(A_T, b, m, n);

            Logger.LogMessage("Решение методом наименьших квадратов через метод Гаусса.", Logger.LogLevel.INFO);

            // Решение системы с помощью метода Гаусса
            return SolveGaussElimination(ATA);
        }

        // Метод для перестановки строк в матрице
        private static void SwapRows(double[,] matrix, int row1, int row2, int numCols)
        {
            for (int j = 0; j < numCols; j++)
            {
                double temp = matrix[row1, j];
                matrix[row1, j] = matrix[row2, j];
                matrix[row2, j] = temp;
            }
        }

        // Метод для транспонирования матрицы
        private static double[,] TransposeMatrix(double[,] matrix, int rows, int cols)
        {
            double[,] transposed = new double[cols, rows];
            for (int i = 0; i < cols; i++)
            {
                for (int j = 0; j < rows; j++)
                {
                    transposed[i, j] = matrix[j, i];
                }
            }
            return transposed;
        }

        // Метод для умножения матриц
        private static double[,] MultiplyMatrices(double[,] A, double[,] B, int aRows, int aCols, int bCols)
        {
            double[,] result = new double[aCols, bCols];
            for (int i = 0; i < aCols; i++)
            {
                for (int j = 0; j < bCols; j++)
                {
                    result[i, j] = 0;
                    for (int k = 0; k < aRows; k++)
                    {
                        result[i, j] += A[i, k] * B[k, j];
                    }
                }
            }
            return result;
        }

        // Метод для умножения матрицы на вектор
        private static double[] MultiplyMatrixVector(double[,] A, double[] b, int rows, int cols)
        {
            double[] result = new double[cols];
            for (int i = 0; i < cols; i++)
            {
                result[i] = 0;
                for (int j = 0; j < rows; j++)
                {
                    result[i] += A[i, j] * b[j];
                }
            }
            return result;
        }
    }
}
