﻿using System;
using System.Text;
using System.Windows.Forms;

namespace kursovaya
{
    public partial class Form1 : Form
    {
        private Printer printer;
        private FileOutput fileOutput;
        private FileInput fileInput;
        private double[,] savedMatrix;

        public Form1()
        {
            InitializeComponent();
            printer = new Printer();
            fileInput = new FileInput(dgvMatrix);
            fileOutput = new FileOutput();

            nudVariableCount.Minimum = 2;
            nudVariableCount.Value = 2;
            nudEquationCount.Minimum = 2;
            nudEquationCount.Value = 2;
            nudDecimalPlaces.Minimum = 0;
            nudDecimalPlaces.Maximum = 100;
            nudDecimalPlaces.Value = 2;

            nudVariableCount.ValueChanged += NudVariableCount_ValueChanged;
            nudEquationCount.ValueChanged += NudEquationCount_ValueChanged;
            nudDecimalPlaces.ValueChanged += NudDecimalPlaces_ValueChanged;
            btnSaveResult.Click += btnSaveResult_Click;
            btnPrint.Click += btnPrint_Click;
            btnLoadFile.Click += btnLoadFile_Click;
        }

        // Метод инициализации формы, вызывается при её загрузке
        private void Form1_Load(object sender, EventArgs e)
        {
            InitializeDataGridView();
            Numerics.NudVariableCount_ValueChanged(nudVariableCount, dgvMatrix);
            Numerics.NudEquationCount_ValueChanged(nudEquationCount, dgvMatrix, ref savedMatrix);
        }

        // Инициализация таблицы данных, создаёт таблицу с учётом количества переменных и уравнений
        private void InitializeDataGridView()
        {
            var currentData = new double[dgvMatrix.RowCount, dgvMatrix.ColumnCount];
            for (int i = 0; i < dgvMatrix.RowCount; i++)
            {
                for (int j = 0; j < dgvMatrix.ColumnCount; j++)
                {
                    var cellValue = dgvMatrix.Rows[i].Cells[j].Value;
                    if (cellValue != null && double.TryParse(cellValue.ToString(), out double value))
                    {
                        currentData[i, j] = value;
                    }
                }
            }

            dgvMatrix.Columns.Clear();
            dgvMatrix.Rows.Clear();

            int variableCount = (int)nudVariableCount.Value;
            int equationCount = (int)nudEquationCount.Value;

            // Добавление столбцов для переменных
            for (int i = 0; i < variableCount; i++)
            {
                dgvMatrix.Columns.Add($"x{i + 1}", $"x{i + 1}");
            }
            dgvMatrix.Columns.Add("b", "Свободный член");

            // Добавление строк для уравнений
            for (int i = 0; i < equationCount; i++)
            {
                dgvMatrix.Rows.Add();
            }

            // Восстановление данных из предыдущего состояния
            for (int i = 0; i < equationCount; i++)
            {
                for (int j = 0; j < variableCount + 1; j++)
                {
                    if (i < currentData.GetLength(0) && j < currentData.GetLength(1))
                    {
                        dgvMatrix.Rows[i].Cells[j].Value = currentData[i, j];
                    }
                }
            }
        }

        // Обработчик изменения количества переменных
        private void NudVariableCount_ValueChanged(object sender, EventArgs e) => InitializeDataGridView();

        // Обработчик изменения количества уравнений
        private void NudEquationCount_ValueChanged(object sender, EventArgs e) => InitializeDataGridView();

        // Обработчик изменения количества знаков после запятой
        private void NudDecimalPlaces_ValueChanged(object sender, EventArgs e) => Numerics.NudDecimalPlaces_ValueChanged(tbResult, nudDecimalPlaces, dgvMatrix);

        // Метод для получения данных матрицы из таблицы
        private double[,] GetMatrixFromGrid()
        {
            int rows = dgvMatrix.RowCount;
            int cols = dgvMatrix.ColumnCount;
            double[,] matrix = new double[rows, cols];

            for (int i = 0; i < rows; i++)
            {
                for (int j = 0; j < cols; j++)
                {
                    var cellValue = dgvMatrix.Rows[i].Cells[j].Value;
                    if (cellValue == null || !double.TryParse(cellValue.ToString(), out double value))
                    {
                        matrix[i, j] = 0;
                    }
                    else
                    {
                        matrix[i, j] = value;
                    }
                }
            }
            return matrix;
        }

        // Обработчик кнопки "Решить", выполняет решение системы уравнений
        private void btnSolve_Click(object sender, EventArgs e)
        {
            try
            {
                double[,] matrix = GetMatrixFromGrid();
                double[] solution;

                // Пытаемся решить систему методом Гаусса, в случае неудачи - методом наименьших квадратов
                try
                {
                    solution = Gauss.SolveGaussElimination(matrix);
                }
                catch (InvalidOperationException)
                {
                    solution = Gauss.SolveLeastSquares(matrix);
                }

                // Форматируем решение с учётом количества знаков после запятой
                int decimalPlaces = (int)nudDecimalPlaces.Value;
                string format = $"F{decimalPlaces}";
                StringBuilder resultBuilder = new StringBuilder();

                for (int i = 0; i < solution.Length; i++)
                {
                    resultBuilder.AppendLine($"x{i + 1} = {solution[i].ToString(format)}");
                }

                tbResult.Text = resultBuilder.ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Произошла ошибка: {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Обработчик кнопки "Сохранить результат", сохраняет результат в файл
        private void btnSaveResult_Click(object sender, EventArgs e)
        {
            try
            {
                if (!string.IsNullOrWhiteSpace(tbResult.Text))
                {
                    fileOutput.SaveToFile(tbResult.Text);
                }
                else
                {
                    MessageBox.Show("Нет результата для сохранения.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Произошла ошибка при сохранении файла: {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Обработчик кнопки "Печать", отправляет результат на печать
        private void btnPrint_Click(object sender, EventArgs e) => printer.Print(tbResult.Text);

        // Обработчик кнопки "Загрузить файл", загружает данные из файла
        private void btnLoadFile_Click(object sender, EventArgs e) => fileInput.LoadFile();
    }
}
